<template>
    <h1 class="font-black text-5xl text-center">
        Seguimiento Pacientes
        <span class="text-indigo-600">Veterinaria</span>
    </h1>
</template>